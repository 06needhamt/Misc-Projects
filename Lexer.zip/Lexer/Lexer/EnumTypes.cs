﻿public enum EnumTypes
{
    INT = 0,
    STRING = 1,
    BOOL = 2,
    DOUBLE = 3,
    FLOAT = 4,
    LONG = 5,
    SHORT = 6,
    BYTE = 7,
    CHAR = 8,
    DECIMAL = 9,
    DATE = 10,
    SINGLE = 11,
}