﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpToNative
{
    enum EnumLogicInstructions
    {
        AND = 0, //And
        OR = 1, //Or
        XOR = 2, //Exclusive or
        NOT = 3,//Not
    }
}
