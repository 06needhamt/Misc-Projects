﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpToNative
{
    public enum EnumAccessModifiers
    {
        NO_MODIFIER = -1,
        PUBLIC = 0,
        PROTECTED = 1,
        PRIVATE = 2,
    }
}
